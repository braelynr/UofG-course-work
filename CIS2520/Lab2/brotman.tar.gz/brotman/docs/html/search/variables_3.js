var searchData=
[
  ['next',['next',['../structNode.html#af67b110ca1a258b793bf69d306929b22',1,'Node']]]
];
