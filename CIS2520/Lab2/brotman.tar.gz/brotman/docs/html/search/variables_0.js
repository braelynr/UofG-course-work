var searchData=
[
  ['data',['data',['../structNode.html#a38b733496e3eff5e0b4fcb11cd9b866a',1,'Node']]],
  ['destroydata',['destroyData',['../structHTable.html#a05b3109f3bbfa3fd4b3e55c0bbd29b8a',1,'HTable']]]
];
