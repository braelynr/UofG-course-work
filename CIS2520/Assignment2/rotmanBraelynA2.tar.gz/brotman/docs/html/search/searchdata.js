var indexSectionsWithContent =
{
  0: "cdehiklnprst",
  1: "hn",
  2: "hp",
  3: "cdehilprs",
  4: "dhknpst",
  5: "hn"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs"
};

