var searchData=
[
  ['client',['client',['../hospital_8h.html#a442f14649eefa15911b3122936e5cf90',1,'hospital.h']]]
];
