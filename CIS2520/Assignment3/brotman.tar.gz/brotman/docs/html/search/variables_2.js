var searchData=
[
  ['id',['ID',['../structclient.html#a95387cea00046cb6565c3e42760f5316',1,'client']]]
];
