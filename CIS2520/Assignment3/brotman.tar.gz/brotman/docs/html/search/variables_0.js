var searchData=
[
  ['code',['code',['../structclient.html#a94d3f269ee8fb0ae4bb2335a14d96a96',1,'client']]],
  ['compare',['compare',['../structHeap.html#ab11468cee0bf82183a92cf2fa8bab107',1,'Heap']]]
];
