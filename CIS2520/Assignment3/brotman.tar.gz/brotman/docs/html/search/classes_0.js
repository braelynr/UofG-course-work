var searchData=
[
  ['client',['client',['../structclient.html',1,'']]]
];
