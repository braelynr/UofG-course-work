var searchData=
[
  ['left',['left',['../structNode.html#ad0976834843c7618677d22a10c495b36',1,'Node']]]
];
