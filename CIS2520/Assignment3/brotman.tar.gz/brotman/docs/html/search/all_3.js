var searchData=
[
  ['getfromback',['getFromBack',['../LinkedListAPI_8h.html#ae9e342a1ac0eaf0412c69292c684e6c3',1,'LinkedListAPI.h']]],
  ['getfromfront',['getFromFront',['../LinkedListAPI_8h.html#aed6180e91efc5e85ad98095b0e561d39',1,'LinkedListAPI.h']]],
  ['getminormax',['getMinOrMax',['../heap_8h.html#ad35b71ae5c43d7a26a577ee0d9297015',1,'heap.h']]]
];
