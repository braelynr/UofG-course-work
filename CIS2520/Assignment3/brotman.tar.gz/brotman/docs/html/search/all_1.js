var searchData=
[
  ['data',['data',['../structNode.html#a38b733496e3eff5e0b4fcb11cd9b866a',1,'Node']]],
  ['deletedatafromlist',['deleteDataFromList',['../LinkedListAPI_8h.html#ae1a14b22705ddc68f907e6732f4d0843',1,'LinkedListAPI.h']]],
  ['deleteheap',['deleteHeap',['../heap_8h.html#ac0ddd1874bd4ad9992a3ab465a54dbbc',1,'heap.h']]],
  ['deletelist',['deleteList',['../LinkedListAPI_8h.html#abc18ab05ec8bd1b4ea085d5b30baf536',1,'LinkedListAPI.h']]],
  ['deleteminormax',['deleteMinOrMax',['../heap_8h.html#a812ef014f7e8c7567d6de69504a2f2af',1,'heap.h']]],
  ['dequeue',['dequeue',['../QueueADT_8h.html#a045ef43f63919ca19115c060344cdac0',1,'QueueADT.h']]],
  ['destroy',['destroy',['../QueueADT_8h.html#a89893c23833b9fa8e7dde90343ca8885',1,'QueueADT.h']]],
  ['destroydata',['destroyData',['../structHeap.html#abc8d0107b18de7599058485d78c2e244',1,'Heap::destroyData()'],['../hospital_8h.html#a57d4c229c1eaa2e9bbf21c266fb6e7d5',1,'destroyData():&#160;hospital.h']]]
];
