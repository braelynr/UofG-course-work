var searchData=
[
  ['deleteheap',['deleteHeap',['../heap_8h.html#ac0ddd1874bd4ad9992a3ab465a54dbbc',1,'heap.h']]],
  ['deleteminormax',['deleteMinOrMax',['../heap_8h.html#a812ef014f7e8c7567d6de69504a2f2af',1,'heap.h']]]
];
