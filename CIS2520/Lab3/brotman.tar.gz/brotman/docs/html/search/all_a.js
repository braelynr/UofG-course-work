var searchData=
[
  ['type',['type',['../structHeap.html#a687e85d124c882bb01f5c9bf91171129',1,'Heap']]]
];
