var searchData=
[
  ['right',['right',['../structNode.html#af99e7102380da88d7c079fa264230cf4',1,'Node']]]
];
