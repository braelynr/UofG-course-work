var searchData=
[
  ['getminormax',['getMinOrMax',['../heap_8h.html#ad35b71ae5c43d7a26a577ee0d9297015',1,'heap.h']]]
];
