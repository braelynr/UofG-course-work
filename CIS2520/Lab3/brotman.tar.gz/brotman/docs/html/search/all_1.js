var searchData=
[
  ['data',['data',['../structNode.html#a38b733496e3eff5e0b4fcb11cd9b866a',1,'Node']]],
  ['deleteheap',['deleteHeap',['../heap_8h.html#ac0ddd1874bd4ad9992a3ab465a54dbbc',1,'heap.h']]],
  ['deleteminormax',['deleteMinOrMax',['../heap_8h.html#a812ef014f7e8c7567d6de69504a2f2af',1,'heap.h']]],
  ['destroydata',['destroyData',['../structHeap.html#abc8d0107b18de7599058485d78c2e244',1,'Heap']]]
];
