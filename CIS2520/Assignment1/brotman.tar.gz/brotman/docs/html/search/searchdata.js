var indexSectionsWithContent =
{
  0: "cdegilnpq",
  1: "clq",
  2: "lq",
  3: "cdegip",
  4: "clnq"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "typedefs"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Typedefs"
};

