var searchData=
[
  ['deletedatafromlist',['deleteDataFromList',['../LinkedListAPI_8h.html#ae1a14b22705ddc68f907e6732f4d0843',1,'LinkedListAPI.h']]],
  ['deletelist',['deleteList',['../LinkedListAPI_8h.html#abc18ab05ec8bd1b4ea085d5b30baf536',1,'LinkedListAPI.h']]],
  ['dequeue',['dequeue',['../QueueADT_8h.html#a045ef43f63919ca19115c060344cdac0',1,'QueueADT.h']]],
  ['destroy',['destroy',['../QueueADT_8h.html#a89893c23833b9fa8e7dde90343ca8885',1,'QueueADT.h']]]
];
