var searchData=
[
  ['queue',['Queue',['../structQueue.html',1,'']]]
];
